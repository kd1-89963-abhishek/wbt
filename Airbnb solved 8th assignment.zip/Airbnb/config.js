module.exports = {
  secret: 'abcdefghijklmnopqrstuvwxyz1234567890',
}