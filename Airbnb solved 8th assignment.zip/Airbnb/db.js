const mysql = require('mysql2/promise');

const pool = mysql.createPool({
    host: 'localhost',
    user: 'KD1-89278-Aman-kumbhalwar',
    password: 'manager',
    port: 3306,
    database: 'airbnb_db',
    connectionLimit: 10,
});

module.exports = pool;